package com.romanini.datascience.vo;

public class ScoreCloseness 
{
	private String vertice;
	private Double score;
	
	public String getVertice() {
		return vertice;
	}
	public void setVertice(String vertice) {
		this.vertice = vertice;
	}
	public Double getScore() {
		return score;
	}
	public void setScore(Double score) {
		this.score = score;
	}
}
