
package com.romanini.datascience.resources;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.codehaus.jackson.map.ObjectMapper;

import com.romanini.datascience.vo.ScoreCloseness;
import edu.uci.ics.jung.algorithms.scoring.ClosenessCentrality;
import edu.uci.ics.jung.graph.DirectedSparseGraph;
import edu.uci.ics.jung.graph.Graph;

@Path("/closeness")
public class ClosenessCentralityResource {

	
	@GET
	@Produces("text/plain")
	/*
	 * Get the closeness centrality
	 */
	public Response getClosenessCentrality() throws IOException, InstantiationException, IllegalAccessException {
		
		String retorno = "";
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = "";
				
		//Graph 
		Graph<String, String> graph = new DirectedSparseGraph<String,String>();
		
		List<ScoreCloseness> closeness = new ArrayList<ScoreCloseness>();
		
		FileReader fr = null;
		
		
		try {
			fr = new FileReader("./edges.dat");
			BufferedReader br = new BufferedReader(fr);
			
			/*
			 * Create an object graph with the vertices / edges
			 * from file edges.dat
			 */
			while((retorno = br.readLine()) != null) {
				String[] edges = retorno.split("\\s+");
				graph.addEdge(edges[0]+"-"+edges[1], edges[0], edges[1]);
				
			}
			
			//Get the closeness scores
			ClosenessCentrality<String, String> cs = new ClosenessCentrality<String,String>(graph);
	        
	        for	(String s:graph.getVertices()) 
	        {
	        	ScoreCloseness scoreCloseness = new ScoreCloseness();
	        	scoreCloseness.setVertice(s.toString());
	        	scoreCloseness.setScore(cs.getVertexScore(s.toString()));
	        	closeness.add(scoreCloseness);
	        }
	        
	     // Sorting by score
	        Collections.sort(closeness, new Comparator<ScoreCloseness>() {
	                @Override
	                public int compare(ScoreCloseness score2, ScoreCloseness score1)
	                {
	                    return  score1.getScore().compareTo(score2.getScore());
	                }
	            });
	        
			//Object to JSON in String
			jsonInString = mapper.writeValueAsString(closeness);
	        
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage()); 
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}catch(Exception err)
		{
			System.out.println(err.getMessage());
		}
				
		finally
		{
			fr.close();	
		}
		
		return Response.status(201).entity(jsonInString).build();
	}
}
