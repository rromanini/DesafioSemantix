package com.romanini.datascience.resources;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/edges")
public class SocialNetworkResource {

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/node1/{node1}/node2/{node2}")
	/*
	 * Register an edge, using the two vertices parameters
	 */
	public Response registerEdge(@PathParam("node1")String node1, @PathParam("node2")String node2) throws IOException 
	{
		String retorno = node1 + " " + node2 ;
		BufferedWriter bw = null;
		FileWriter fw = null;
		try
		{
			fw = new FileWriter("./edges.dat", true);
			bw = new BufferedWriter(fw);

			//write the two vertices in the end of file edges.dat 
			bw.write("\r\n" + retorno);

		} catch (IOException e) {
			e.printStackTrace();
		}

		finally
		{
			bw.close();
			fw.close();			
		}

		return Response.status(201).entity("Edge " + retorno + " registered sucessfully!").build();
	}
}
